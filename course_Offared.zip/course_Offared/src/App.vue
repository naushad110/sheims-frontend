

<template>
  <header>
        <div class="icon"></div>
       
        <div class="data"> <ul>
            <li>LMS</li> 
            <li>My IUB</li>
            <li>Eportal</li>
            <li>Gallary</li>
            <li>News cuts</li>
            <li>Tenders</li>
            <li>Rules</li>
            <li>Careers</li>
            <li>Download</li>
        </ul>
    </div>
</header>
<section>
    <div class="img"><img src="/greyheader.png" width="400px" height="50px" alt=""> </div>
        <ul>
            <li>About</li>
            <li>Administration</li>
            <li>Admissions</li>
            <li>Acadmics</li>
            <li>Campuses</li>
            <li>Campus life</li>
            <li>Publications</li>
        </ul>
</section>
<section class="sec3">
   <div>
    <input type="search" placeholder="Enter Max 30 Letters"><button class="search">search</button>
   </div>
 </section>
 <div class="background">
  <h1>Course offered</h1>
  <table  class="tableofCourse">

    <thead>
      <tr class="frow">
        <th>
          Sr. NO.


        </th>
        <th>
          Faculty
        </th>
    

        <th>
          Course


        </th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td rowspan="9">
          1
        </td>
        <td rowspan="9">
          Faculty of Computing
        </td>

        <td> BS Computer Science</td>

      </tr>
      <tr>
    
        <!-- <td>
          Faculty of Computing
        </td> -->
        <td> BS Information System</td>
      </tr>
      <tr>
  
        
        <td>
          BS Digital Media
        </td>

      </tr>
      <tr>
      
        <td>
          BS Information Technology
        </td>
      </tr>
      <tr>
  
        <td>
          BS Software Engineering
        </td>
      </tr>
      <tr>
   
        <td>
          BS Atificial Intelligence
        </td>
      </tr>
      <tr>
 
        <td>
          BS Information Security
        </td>
      </tr>
      <tr>
     
        <td>
          BS Data Science
        </td>
      </tr>
      <tr>
    
        <td>
          BS Statistics
        </td>
      </tr>
      <br>
      <tr>

      </tr>
      <tr>
        <tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>

</tr>
      <tr>
        <td rowspan="8">2</td>
        <td rowspan="8"  >Faculty of Engineering</td>
        <td>BS Civil Engineering</td>
      </tr>
      <tr>
        <td>BS BioMedical Electronics</td>
      </tr>
      <tr>
        <td>BS Electrical Engineering</td>
      </tr>    <tr>
        <td>BS Intelligence System & Robotics Engineering</td>
      </tr>    <tr>
        <td>BS Cyber Security & Digital Forensic </td>
      </tr>    <tr>
        <td>BS Aviation Science</td>
      </tr>    <tr>
        <td>BS Aviation Management</td>
      </tr>    <tr>
        <td>BS Architecture</td>
      </tr>
      <tr>
        <tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
</tr>
      <tr>
        <td rowspan="6">3</td>
        <td    rowspan="6">Faculty of chemical & biological science</td>
        <td>BS Botony </td>
      </tr>
      <tr>
        <td>BS chemistry </td>
      </tr>
      <tr>
        <td>BS zology </td>
      </tr>
      <tr>
        <td>BS biochemistry </td>
      </tr>
      <tr>
        <td>BS Biotechnology </td>
      </tr>
      <tr>
        <td>BS Bioinformatics </td>
      </tr>
      <tr>
        <tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
</tr>
      <tr>
        <td rowspan="10">4</td>
        <td    rowspan="10">Faculty of Arts & Language</td>
      </tr>
      <tr>
        <td>BS English Langauge  & Literature</td>
      </tr>
      <tr>
        <td>BS English Langauge  & Linguistics</td>
      </tr>
      <tr>
        <td>BS History</td>
      </tr>
      <tr>
        <td>BS Archeology</td>
      </tr>
      <tr>
        <td>
          BS Pakistan Studies

        </td>
      </tr>
      <tr>
        <td> BS Persian </td>
      </tr>
      <tr>
        <td>BS Persian</td>
      </tr>
      <tr>
        <td>
          BS Urdu
        </td>
      </tr>
      <tr>
        <td>BS Iqbal Studies</td>
      </tr>
      <tr>
        <tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
</tr>
      <tr>
        <td rowspan="5">5</td>
        <td    rowspan="5">Faculty of Agriculture & Environment</td>
        <td>BS Agriculture  </td>
      </tr>
     <tr>
      <td>BS Forestry</td>
     </tr>
     <tr>
      <td>BS Environment Sciences</td>
     </tr>
     <tr>
      <td>BS Agri Science</td>
     </tr>
     <tr>
   
 <td>       
  BSc Food Science & Technology </td>
    </tr>
    <tr>
        <tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
</tr>
      <tr>
        <td rowspan="17">6</td>
        <td    rowspan="17">Faculty of Social Sciences</td>
        <td>BS Applied Psychology </td>
      </tr>
     <tr>
      <td>BS Economics</td>
     </tr>
     <tr>
      <td>BS Buisness Economics</td>
     </tr>
     <tr>
      <td>BS Economics & Finanace</td>
     </tr>
     <tr>
   
 <td>       
  BS Development Studies</td>
    </tr>
     <tr>
   
 <td>       
  BS International Relations</td>
    </tr>
     <tr>
   
 <td>       
  BS Defence & Deplomatic Studies</td>
    </tr>
     <tr>
   
 <td>       
  BS Information Management</td>
    </tr>
     <tr>
   
 <td>       
  BS Mass Communication </td>
    </tr>
     <tr>
   
 <td>       
  BS Political Science</td>
    </tr>
     <tr>
   
 <td>       
  BS Politics & Parlimentary Studies</td>
    </tr>
     <tr>
   
 <td>       
  BS Gender Studies</td>
    </tr>
     <tr>
   
 <td>       
  BS Public Policy & Governance</td>
    </tr>
     <tr>
   
 <td>       
  BS Public Adminstration</td>
    </tr>
     <tr>
   
 <td>       
  BS Social Work</td>
    </tr>
     <tr>
   
 <td>       
  BS Sociology</td>
    </tr>
     <tr>
   
 <td>       
  BS Anthropology</td>
    </tr>
    <tr>
        <tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
</tr>
    <tr>
      <td rowspan="4">7</td>
      <td rowspan="4">Faculty of istamic learning</td>
      <td>BS Arabic </td>
    </tr>
    <tr>
      <td>BS islamic Studies with specialization in islamic studies </td>
    </tr>
    <tr>
      <td>BS hadit studies ,quranic studies,world religions &interfaith harmony </td>
    </tr>
    <tr>
      <td>BS Transalation studies </td>
    </tr>
    <tr>
        <tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
</tr>
    <tr>
      <td rowspan="10">8</td>
      <td rowspan="10">faculty of management science and commerce</td>
      <td>BS Commerce</td>
    </tr>
    <tr>
      <td>BS Accounting & finance</td>
    </tr>
    <tr>
      <td>BS Banking and finance</td>
    </tr>
    <tr>
      <td>BS supply chain management</td>
    </tr>
    <tr>
      <td>BS Digital marketing</td>
    </tr>
    <tr>
      <td>BS leadership and management</td>
    </tr>
    <tr>
      <td>BS in disarter Management</td>
    </tr>
    <tr>
      <td>BS Enterpreneurship & innovation</td>
    </tr>
    <tr>
      <td>BS E-commerce</td>
    </tr>
    <tr>
      <td>BS fin-tech</td>
    </tr>
    <tr>
        <tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
</tr>
    <tr>
      <td rowspan="5">9</td>
      <td rowspan="5">faculty of veterinary & animal sciences</td>
      <td>BS Animal science</td>
    </tr>
    <tr>
      <td>livestock Assistant Diploma </td>
    </tr>
    <tr>
      <td>BS  Applied Microbiology</td>
    </tr>
    <tr>
      <td>BS Physiology science</td>
    </tr>
    <tr>
      <td>BS Poultry science</td>
    </tr>
    <tr>
        <tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
</tr>
    <tr>
      <td rowspan="6">10</td>
      <td rowspan="6">faculty of Medical & Allied  health science </td>
      <td>BS human Nutritions & Dietetics</td>
    </tr>
    <tr>
      <td>Doctor of physical therapy</td>
    </tr>
    <tr>
      <td>BS Medical labortary Technology</td>
    </tr>
    <tr>
      <td>BS Forensic Science</td>
    </tr>
    <tr>
      <td>BS Public Health</td>
    </tr>
    <tr>
      <td> CHPE</td>
    </tr>
    <tr>
        <tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
</tr>
    <tr>
      <td rowspan="8">11</td>
      <td rowspan="8">faculty of Education</td>
      <td>BS Education</td>
    </tr>
    <tr>
      <td>BS Secondary Education</td>
    </tr>
    <tr>
      <td>BS Elementary Education</td>
    </tr>
    <tr>
      <td>BS Eudcational leadership & Management</td>
    </tr>
    <tr>
      <td>BS  physical Education and sports science </td>
    </tr>
    <tr>
      <td>BS Special Education</td>
    </tr>
    <tr>
      <td>BS Eudcational planning & Management</td>
    </tr>
    <tr>
      <td>BS English Language & Teaching</td>
    </tr>
    <tr>
        <tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
</tr>
    <tr>
      <td>12</td>
      <td>faculty of Pharmacy</td>
      <td>Diploma in pharmaceutical regulatory Affairs</td>
    </tr>
    
    <tr>
        <tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
<tr>

</tr>
</tr>

    


    </tbody>









  </table></div>
</template>




<style scoped>


body {
  margin: 0px;
  padding: 0px;
}
.tableofCourse {

text-align: center;
margin: 0 auto;
width: 50%;


}
th,td,tr{
  border: 1px solid black;
  border-spacing: 0px;
}
/* th{
  background-color: lightblue;
} */
td{
  padding:0px;
}
h1{
  text-align: center;
}
header{
    background-color: #29377c;
}
.data{
    float: right;
    margin-top: 8px;
    padding-right: 30px;
}
.data ul li {
    display: inline;
    color: white;
    padding: 10px;
    padding-right: 10px;
}
.data ul li:hover{
    background-color: #E3AE1D;
}
.icon{
    display: inline-block;
    color: white;
    opacity: 0.5;
    padding: 15px;
    padding-left: 60px;
    word-spacing: 20px;
}
.icon i{
    border-right: 2px solid black;  
}
.data ul{
    display: inline;
    
}
body{
    margin: 0px;
}
section ul {
    display: inline;
  float: right;
}
section ul :hover{
    color:  #E3AE1D;
}
section{
    margin-top: 40px;
}
section ul li{
    list-style: none;
    display: inline;
    font-size: 20px;
    padding-right: 20px;
    font-weight: bold;
}
section .img{
    margin-left: 80px;
    display: inline;
}
.sec3{
    text-align: center;
    background-color: #29377c;
    padding: 20px;
}
.sec3 div input {
    padding: 15px;
    width: 600px;
    border: 0px;
}
.sec3 div  button{
    padding: 15px;
    width: 100px;
    border: 0px;
    background-color: #E3AE1D;
    color: white;
    text-transform: uppercase;
}

.background{
  background-color:  lightgray;
  margin: 0;
  padding: 0;
}

.frow {
  background-color:  #29377c;
  color: white;
}

</style>
